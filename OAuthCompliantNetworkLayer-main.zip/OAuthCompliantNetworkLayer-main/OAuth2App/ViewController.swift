//
//  ViewController.swift
//  OAuth2App
//
//  Created by Saleh Masum on 26/8/2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

