//
//  LibraryViewController.swift
//  OAuth2App
//
//  Created by Saleh Masum on 27/8/2022.
//

import UIKit

class LibraryViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
    }
    

}
